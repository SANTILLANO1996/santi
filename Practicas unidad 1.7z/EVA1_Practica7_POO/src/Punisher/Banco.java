/*
 * 
 * 
 * 
 */
package Punisher;
public class Banco
{
    //acceso publico
    public String nombre;
    public double Saldo;
}
